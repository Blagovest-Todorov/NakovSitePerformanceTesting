# MVC App: Students Registry

MVC app example: a registry of students, which implements:
 - View students
 - Add new student

The app is based on Node.js + Express.js + Pug.

Live demo at https://repl.it/@nakov/mvc-app-node-express

GitHub: https://github.com/nakov/MVC-app-integration-tests-example-mocha

